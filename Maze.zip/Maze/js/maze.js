window.onload = function () {
  var
  	canvas,
  	context,
  	theMaze = null,
    solutionColorFlag = null,

  	pathWidth      = 10,                      //Width of the Maze Path
  	wall           = 2,                       //Width of the Walls between Paths
  	outerWall      = 2,                       //Width of the Outer most wall
  	width          = 25                      //Number paths fitted horisontally
  	height         = 25,                      //Number paths fitted vertically
  	seed           = Math.random()*100000|0,  //Seed for random numbers
  	wallColor      = '#d24',                  //Color of the walls
  	pathColor      = '#222a33',               //Color of the path
  	solutionColor  = '#47bb40',               //Color of the solution path

  	inputWidth          = document.getElementById('width'),
  	inputHeight         = document.getElementById('height'),
  	inputPathWidth      = document.getElementById('pathwidth'),
  	inputWallWidth      = document.getElementById('wallwidth'),
  	inputOuterWidth     = document.getElementById('outerwidth'),
  	inputPathColor      = document.getElementById('pathcolor'),
  	inputWallColor      = document.getElementById('wallcolor'),
  	inputSeed           = document.getElementById('seed'),
  	solutionColorInput  = document.getElementById('solutionColor'),
  	buttonRandomSeed    = document.getElementById('randomseed'),
  	clearSolution       = document.getElementById('clearSolution'),
  	solutionGenerator   = document.getElementById('solutionGenerator');


  settings = {
    display: function(){
      inputWidth.value = width
      inputHeight.value = height
      inputPathWidth.value = pathWidth
      inputWallWidth.value = wall
      inputOuterWidth.value = outerWall
      inputPathColor.value = pathColor
      inputWallColor.value = wallColor
      inputSeed.value = seed
      solutionColorInput.value = solutionColor
    },
    check: function(){
      if(inputWidth.value != width||
         inputHeight.value != height||
         inputPathWidth.value != pathWidth||
         inputWallWidth.value != wall||
         inputOuterWidth.value != outerWall||
         inputPathColor.value != pathColor||
         inputWallColor.value != wallColor||
         solutionColorInput.value != solutionColor||
         inputSeed.value != seed){
        settings.update()
      }
    },
    update: function(){
      width          = parseFloat(inputWidth.value)
      height         = parseFloat(inputHeight.value)
      pathWidth      = parseFloat(inputPathWidth.value)
      wall           = parseFloat(inputWallWidth.value)
      outerWall      = parseFloat(inputOuterWidth.value)
      pathColor      = inputPathColor.value
      wallColor      = inputWallColor.value
      solutionColor  = solutionColorInput.value
      seed           = parseFloat(inputSeed.value)
      makeMaze();
    }
  }

  settings.display();

  setInterval(settings.check,100)

	canvas = document.querySelector('canvas');
	context = canvas.getContext('2d');

  buttonRandomSeed.addEventListener('click',function(){
    solutionColorFlag = null;
    inputSeed.value = Math.random()*100000|0
  })

  solutionGenerator.addEventListener('click',function(){
    solutionColorFlag = solutionColor;
    solveMaze();
  })

  clearSolution.addEventListener('click',function(){
    solutionColorFlag = null
  	theMaze.clearSolution();
  	theMaze.draw();
  })

  function makeMaze() {
    solutionColorFlag = null;
  canvas.style.border = outerWall - 1 + "px solid " + wallColor
  	var rows = height;
  	var columns = width;
  	var gridsize = pathWidth + wall;
  	var mazeStyle = 'curvy';
  	var startColumn = 0;
  	var startRow = 0;
  	var endColumn = columns - 1;
  	var endRow = rows - 1;


  	theMaze = new maze(rows, columns, gridsize, mazeStyle, startColumn, startRow, endColumn, endRow, wallColor, pathColor, solutionColor);
  	theMaze.generate();
  	theMaze.draw();
  }

  function solveMaze() {
  	if (theMaze !== null) {
  		theMaze.solve();
  		theMaze.draw();
  	} else {
      alert('Generate a maze first!');
  	}
  }

  function maze(rows, columns, gridsize, mazeStyle, startColumn, startRow, endColumn, endRow, wallColor, backgroundColor, solutionColor) {
  	this.rows = rows;
  	this.columns = columns;
  	this.gridsize = gridsize;
  	this.mazeStyle = mazeStyle;
  	this.sizex = gridsize * rows;
  	this.sizey = gridsize * columns;
  	this.halfgridsize = this.gridsize / 2;
  	this.grid = new Array(this.columns);
  	this.history = new Array();
  	this.startColumn = parseInt(startColumn);
  	this.startRow = parseInt(startRow);
  	this.playerX = this.startColumn;
  	this.playerY = this.startRow;
  	this.endColumn = parseInt(endColumn);
  	this.endRow = parseInt(endRow);
  	this.wallColor = wallColor;
  	this.backgroundColor = backgroundColor;
  	this.solutionColor = solutionColor;
  	this.lineWidth = 2 * (Math.ceil(parseInt(wall)/2));
    console.log(this.lineWidth);
  	this.genStartColumn = Math.floor(Math.random() * (this.columns- 1));
  	this.genStartRow = Math.floor(Math.random() * (this.rows- 1));
  	this.cellCount = this.columns * this.rows;
  	this.generatedCellCount = 0;
  	for (i = 0; i < columns; i++) {
  		this.grid[i] = new Array(rows);
  	}
  	for (j = 0; j < this.columns; j++) {
  		for (k = 0; k < this.rows; k++) {
  			var isStart = false;
  			var isEnd = false;
  			var partOfMaze = false;
  			var isGenStart = false;
  			if (j == this.startColumn && k == this.startRow) {
  				isStart = true;
  			}
  			if (j == this.genStartColumn && k == this.genStartRow) {
  				partOfMaze = true;
  				isGenStart = true;
  			}
  			if (j == this.endColumn && k == this.endRow) {
  				isEnd = true;
  			}
  			this.grid[j][k] = new cell(j, k, partOfMaze, isStart, isEnd, isGenStart);
  		}
  	}
  }

  maze.prototype.generate = function() {
  	var theMaze = this;
  	var currentCell = this.grid[this.genStartColumn][this.genStartRow];
  	var nextCell;
  	var leftCellPartOfMaze = false;
  	var topCellPartOfMaze = false;
  	var rightCellPartOfMaze = false;
  	var bottomCellPartOfMaze = false;
  	var currentX = this.genStartColumn;
  	var currentY = this.genStartRow;
  	var changeX = 0;
  	var changeY = 0;
  	var previousChangeX = 0;
  	var previousChangeY = 0;
  	var leftCell;
  	var topCell;
  	var rightCell;
  	var bottomCell;
  	var direction;
  	var leftChoices;
  	var rightChoices;
  	var downChoices;
  	var upChoices;
  	var biasDirection;
  	var choices;
  	while (this.generatedCellCount < this.cellCount - 1) {
  		doGeneration();
  	}
  	function chooseCell() {
  		changeX = 0;
  		changeY = 0;
  		choices = [];
  		biasDirection = '';
  		if (previousChangeX == -1) {
  			biasDirection = 'left';
  		} else if (previousChangeX == 1) {
  			biasDirection = 'right';
  		} else if (previousChangeY == -1) {
  			biasDirection = 'up';
  		} else if (previousChangeY == 1) {
  			biasDirection = 'down';
  		}
  		direction = '';
  		leftChoices = [0, 0, 0, 0, 0];
  		upChoices = [1, 1, 1, 1, 1];
  		rightChoices = [2, 2, 2, 2, 2];
  		downChoices = [3, 3, 3, 3, 3];
  		switch (theMaze.mazeStyle) {

  		case "curvy": {
  			if (biasDirection == 'left') {
  				leftChoices = [0, 0];
  			} else if (biasDirection == 'right') {
  				rightChoices = [2, 2];
  			} else if (biasDirection == 'down') {
  				downChoices = [3, 3];
  			} else if (biasDirection == 'up') {
  				upChoices = [1, 1]
  			}
  			break;
  		}
  		}
  		choices = leftChoices.concat(rightChoices.concat(downChoices.concat(upChoices)));
  		var rand = Math.floor(Math.random() * choices.length);
  		var weightedRand = choices[rand];
  		switch(weightedRand) {
  		case 0: {
  			nextCell = leftCell;
  			changeX = -1;
  			direction = 'left';
  			break;
  		}
  		case 1: {
  			nextCell = topCell;
  			changeY = -1;
  			direction = 'up';
  			break;
  		}
  		case 2: {
  			nextCell = rightCell;
  			changeX = 1;
  			direction = 'right';
  			break;
  		}
  		case 3: {
  			nextCell = bottomCell;
  			changeY = 1;
  			direction = 'down';
  			break;
  		}
  		default: {
  			nextCell = null;
  			changeY = 0;
  			changeX = 0;
  			break;
  		}
  		}

  		if (nextCell == null || nextCell.partOfMaze == true) {
  			chooseCell();
  		} else {
  			currentX += changeX;
  			currentY += changeY;
  			previousChangeX = changeX;
  			previousChangeY = changeY;
  			theMaze.history.push(direction);
  		}
  	}
  	function addToMaze() {
  		nextCell.partOfMaze = true;
  		if (changeX == -1) {
  			currentCell.leftWall = false;
  			nextCell.rightWall = false;
  		}
  		if (changeY == -1) {
  			currentCell.topWall = false;
  			nextCell.bottomWall = false;
  		}
  		if (changeX == 1) {
  			currentCell.rightWall = false;
  			nextCell.leftWall = false;
  		}
  		if (changeY == 1) {
  			currentCell.bottomWall = false;
  			nextCell.topWall = false;
  		}
  	}
  	function doGeneration() {
  		if (theMaze.generatedCellCount == theMaze.cellCount - 1) {
  			return;
  		}
  		changeX = 0;
  		changeY = 0;
  		if (currentX > 0) {
  			leftCell = theMaze.grid[currentX - 1][currentY];
  			leftCellPartOfMaze = leftCell.partOfMaze;
  		} else {
  			leftCell = null;
  			leftCellPartOfMaze = true;
  		}
  		if (currentY > 0) {
  			topCell = theMaze.grid[currentX][currentY - 1];
  			topCellPartOfMaze = topCell.partOfMaze;

  		} else {
  			topCell = null;
  			topCellPartOfMaze = true;
  		}
  		if (currentX < (theMaze.columns - 1)) {
  			rightCell = theMaze.grid[currentX + 1][currentY];
  			rightCellPartOfMaze = rightCell.partOfMaze;
  		} else {
  			rightCell = null;
  			rightCellPartOfMaze = true;
  		}
  		if (currentY < (theMaze.rows - 1)) {
  			bottomCell = theMaze.grid[currentX][currentY + 1];
  			bottomCellPartOfMaze = bottomCell.partOfMaze;
  		} else {
  			bottomCell = null;
  			bottomCellPartOfMaze = true;
  		}
  		if (leftCellPartOfMaze == true && topCellPartOfMaze == true && rightCellPartOfMaze == true && bottomCellPartOfMaze == true) {
  			//go back and check previous cell for generation
  			var lastDirection = theMaze.history.pop();
  			changeX = 0;
  			changeY = 0;
  			switch (lastDirection) {
  			case 'left': {
  				changeX = 1;
  				break;
  			}
  			case 'up': {
  				changeY = 1;
  				break;
  			}
  			case 'right': {
  				changeX = -1;
  				break;
  			}
  			case 'down': {
  				changeY = -1;
  				break;
  			}
  			}
  			nextCell = theMaze.grid[currentX + changeX][currentY + changeY];
  			currentX += changeX;
  			currentY += changeY;
  			currentCell = nextCell;
  				doGeneration();

  		} else {
  			chooseCell();
  			addToMaze();
  			currentCell = nextCell;
  			theMaze.generatedCellCount += 1;
  		}
  	}
  }






  maze.prototype.draw = function() {
  	var totalWidth = this.columns * this.gridsize;
  	var totalHeight = this.rows * this.gridsize;

    console.log('totalWidth : ' + totalWidth);
    console.log('totalHeight : ' + totalHeight);

    canvas.width = totalWidth;
    canvas.height = totalHeight;
  	context.lineWidth = this.lineWidth;
    console.log('lineWidth : ' + this.lineWidth);
    context.lineCap = 'square'

  	context.clearRect(0, 0, Math.ceil(totalWidth), Math.ceil(totalHeight));
  	context.strokeStyle = this.wallColor;


  	for (j = 0; j < this.columns; j++) {
  		for (k = 0; k < this.rows; k++) {
  			var drawX = (j * this.gridsize);
  			var drawY = (k * this.gridsize);
  			var pastX = parseInt(drawX) + parseInt(this.gridsize);
  			var pastY = parseInt(drawY) + parseInt(this.gridsize)
  			var theCell = this.grid[j][k];
  			// this.drawColors(theCell);

  			if (theCell.partOfSolution == true) {
  				context.fillStyle = this.solutionColor;
  			} else {
  				context.fillStyle = this.backgroundColor;
  			}
  			if (theCell.isStart == true) {
  				// context.fillStyle = "#00FF00";
  			}
  			if (theCell.isEnd == true) {
  				context.fillStyle = solutionColorFlag;
  			}
  			if (theCell.isGenStart == true) {
  				//context.fillStyle = "#0000FF";
  			}

  			context.fillRect(drawX, drawY + .5 * wall, Math.ceil(this.gridsize), Math.ceil(this.gridsize));
  			context.beginPath();
  			if (theCell.leftWall == true) {
  				//context.strokeRect(drawX, drawY, 1, this.gridsize);
  				context.moveTo(drawX, drawY);
  				context.lineTo(drawX, pastY);
  			}
  			if (theCell.topWall == true) {
  				context.moveTo(drawX, drawY);
  				context.lineTo(pastX, drawY);
  			}
  			if (theCell.rightWall == true) {
  				context.moveTo(pastX, drawY);
  				context.lineTo(pastX, pastY);
  			}
  			if (theCell.bottomWall == true) {
  				context.moveTo(drawX, pastY);
  				context.lineTo(pastX, pastY);
  			}
  			context.closePath();
  			context.stroke();
  		}
  	}
  }

  maze.prototype.clearSolution = function() {
  	theMaze = this;
  	for (j = 0; j < this.columns; j++) {
  		for (k = 0; k < this.rows; k++) {
  			theMaze.grid[j][k].partOfSolution = false;
  			theMaze.grid[j][k].visited = false;
  		}
  	}
  }

  maze.prototype.solve = function() {
  	theMaze = this;
  	theMaze.clearSolution();
  	this.history = new Array();
  	var currentCell = this.grid[this.startColumn][this.startRow];
  	var endCell = this.grid[this.endColumn][this.endRow];
  	var currentX = this.startColumn;
  	var currentY = this.startRow;
  	var changeX = 0;
  	var changeY = 0;
  	var leftCell = null;
  	var topCell = null;
  	var rightCell = null;
  	var bottomCell = null;
  	var leftCellVisited = null;
  	var topCellVisited = null;
  	var rightCellVisited = null;
  	var bottomCellVisited = null;
  	var i = 0;
  	while (currentCell.isEnd !== true) {
  		doSolve();
  	}
  	markSolutionCells();
  	function doSolve() {

  		function getSurroundingCells() {
  			if (currentX > 0) {
  				leftCell = theMaze.grid[currentX - 1][currentY];
  				leftCellVisited = leftCell.visited;
  			} else {
  				leftCell = null;
  				leftCellVisited = true;
  			}
  			if (currentY > 0) {
  				topCell = theMaze.grid[currentX][currentY - 1];
  				topCellVisited = topCell.visited;
  			} else {
  				topCell = null;
  				topCellVisited = true;
  			}
  			if (currentX < (theMaze.columns - 1)) {
  				rightCell = theMaze.grid[currentX + 1][currentY];
  				rightCellVisited = rightCell.visited;
  			} else {
  				rightCell = null;
  				rightCellVisited = true;
  			}
  			if (currentY < (theMaze.rows - 1)) {
  				bottomCell = theMaze.grid[currentX][currentY + 1];
  				bottomCellVisited = bottomCell.visited;
  			} else {
  				bottomCell = null;
  				bottomCellVisited = true;
  			}
  		}
  		function chooseDirection() {
  			var move = false;
  			var direction = '';
  			changeX = 0;
  			changeY = 0;
  			var rand = Math.floor(Math.random() * 4);
  			switch(rand) {
  			case 0: {
  				if (currentCell.leftWall == false && leftCellVisited == false) {
  					changeX = -1;
  					direction = 'left';
  					move = true;
  				}
  				break;
  			}
  			case 1: {
  				if (currentCell.topWall == false && topCellVisited == false) {
  					changeY = -1;
  					direction = 'up';
  					move = true;
  				}
  				break;
  			}
  			case 2: {
  				if (currentCell.rightWall == false && rightCellVisited == false) {
  					changeX = 1;
  					direction = 'right';
  					move = true;
  				}
  				break;
  			}
  			case 3: {
  				if (currentCell.bottomWall == false && bottomCellVisited == false) {
  					changeY = 1;
  					direction = 'down';
  					move = true;
  				}
  				break;
  			}
  			default: {
  				move = false;
  				changeY = 0;
  				changeX = 0;
  				break;
  			}
  			}
  			if (move == true) {
  				theMaze.history.push(direction);

  			} else {
  				chooseDirection();
  			}
  		}

  		//do actual solve routine
  		currentCell.visited = true;
  		getSurroundingCells();
  		if (currentCell.isEnd == true) {
  			markSolutionCells();
  		} else {
  			if ((currentCell.leftWall == false && leftCellVisited == false) || (currentCell.topWall == false && topCellVisited == false) || (currentCell.rightWall == false && rightCellVisited == false) || (currentCell.bottomWall == false && bottomCellVisited == false)) {
  				chooseDirection();
  			} else {
  				lastDirection = theMaze.history.pop();
  				changeX = 0;
  				changeY = 0;
  				switch (lastDirection) {
  				case 'left': {
  					changeX = 1;
  					break;
  				}
  				case 'up': {
  					changeY = 1;
  					break;
  				}
  				case 'right': {
  					changeX = -1;
  					break;
  				}
  				case 'down': {
  					changeY = -1;
  					break;
  				}
  				}
  			}
  			currentX += changeX;
  			currentY += changeY;
  			currentCell = theMaze.grid[currentX][currentY];
  			//doSolve();
  		}
  	}
  	function markSolutionCells() {
  		currentCell = theMaze.grid[theMaze.startColumn][theMaze.startRow];
  		currentX = theMaze.startColumn;
  		currentY = theMaze.startRow;
  		for (m = 0; m < theMaze.history.length; m++) {
  			var solutionDirection = theMaze.history[m];
  			currentCell.partOfSolution = true;
  			changeX = 0;
  			changeY = 0;
  			switch (solutionDirection) {
  			case 'left': {
  				changeX = -1;
  				break;
  			}
  			case 'up': {
  				changeY = -1;
  				break;
  			}
  			case 'right': {
  				changeX = 1;
  				break;
  			}
  			case 'down': {
  				changeY = 1;
  				break;
  			}
  			}
  			currentX += changeX;
  			currentY += changeY;
  			currentCell = theMaze.grid[currentX][currentY];
  		}
  	}
  }

  function cell(column, row, partOfMaze, isStart, isEnd, isGenStart) {
  	this.x = column;
  	this.y = row;
  	this.leftWall = true;
  	this.topWall = true;
  	this.rightWall = true;
  	this.bottomWall = true;
  	this.partOfMaze = partOfMaze;
  	this.isStart = isStart;
  	this.isEnd = isEnd;
  	this.partOfSolution = false;
  	this.visited = false;
  	this.isGenStart = isGenStart;
  	this.isPlayer = false;
  }

  makeMaze();
}
